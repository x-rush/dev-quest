#!/usr/bin/env bash
set -uo pipefail
swiftc --version > /reports/version.txt
: > /reports/status.tsv
for source in /blocks/*.swift; do
  name=$(basename "$source" .swift)
  timeout 60 swiftc -swift-version 6 -parse "$source" > "/reports/$name.log" 2>&1
  status=$?
  printf '%s\t%s\n' "$name" "$status" >> /reports/status.tsv
done