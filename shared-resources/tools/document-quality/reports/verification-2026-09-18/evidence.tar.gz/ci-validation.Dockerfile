FROM golang:1 AS go
FROM node:24-bookworm-slim AS node
RUN npm install --global typescript@5.9.3
FROM rust:1-slim-bookworm AS rust
FROM eclipse-temurin:21-jdk-noble
RUN sed -i 's|http://|https://|g' /etc/apt/sources.list.d/ubuntu.sources && apt-get -o Acquire::Retries=3 -o Acquire::https::Timeout=30 update && apt-get -o Acquire::Retries=3 -o Acquire::https::Timeout=30 install -y --no-install-recommends python3 python3-yaml php-cli protobuf-compiler bash git ca-certificates && rm -rf /var/lib/apt/lists/*
COPY --from=go /usr/local/go /usr/local/go
COPY --from=node /usr/local/bin/node /usr/local/bin/node
COPY --from=node /usr/local/lib/node_modules /usr/local/lib/node_modules
COPY --from=rust /usr/local/cargo /usr/local/cargo
COPY --from=rust /usr/local/rustup /usr/local/rustup
ENV PATH="/usr/local/go/bin:/usr/local/lib/node_modules/typescript/bin:/usr/local/cargo/bin:${PATH}"
ENV RUSTUP_HOME=/usr/local/rustup CARGO_HOME=/usr/local/cargo
WORKDIR /workspace
RUN apt-get -o Acquire::Retries=3 -o Acquire::https::Timeout=30 update && apt-get -o Acquire::Retries=3 -o Acquire::https::Timeout=30 install -y --no-install-recommends gcc libc6-dev && rm -rf /var/lib/apt/lists/*
RUN rustup component add rustfmt

COPY kotlin-toolchain/kotlinc /opt/kotlinc
RUN chmod +x /opt/kotlinc/bin/*
ENV PATH="/opt/kotlinc/bin:${PATH}"
