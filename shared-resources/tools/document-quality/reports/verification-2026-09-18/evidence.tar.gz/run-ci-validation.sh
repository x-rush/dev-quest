#!/usr/bin/env bash
set -euo pipefail
mkdir -p /workspace /tmp/dq-verify/parsego
tar -C /source --exclude=.git -cf - . | tar -C /workspace -xf -
cd /workspace
go build -o /tmp/dq-verify/parsego/parsego shared-resources/tools/code-block-verify/parsego/main.go
python3 shared-resources/tools/code-block-verify/test_parsego.py /tmp/dq-verify/parsego/parsego
python3 -m unittest discover -s shared-resources/tools/code-block-verify -p test_verifier.py
python3 shared-resources/tools/code-block-verify/extract_blocks.py .
set +e
python3 shared-resources/tools/code-block-verify/verify.py --strict --execute 2>&1 | tee /reports/run.log
verification_status=${PIPESTATUS[0]}
set -e
for artifact in manifest.jsonl manifest.jsonl.index.json results.jsonl commands.jsonl summary.json report.md; do
  if [ -f shared-resources/tools/code-block-verify/"$artifact" ]; then
    cp shared-resources/tools/code-block-verify/"$artifact" /reports/
  fi
done
printf '%s\n' "$verification_status" > /reports/exit-code.txt
exit "$verification_status"
