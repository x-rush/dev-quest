#!/bin/sh
php --version > /reports/version.txt
: > /reports/status.tsv
for source in /blocks/*.php; do
  name=$(basename "$source" .php)
  php -l "$source" > "/reports/$name.log" 2>&1
  status=$?
  printf '%s\t%s\n' "$name" "$status" >> /reports/status.tsv
done