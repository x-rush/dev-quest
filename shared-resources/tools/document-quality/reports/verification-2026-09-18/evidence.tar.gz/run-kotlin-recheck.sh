#!/usr/bin/env bash
set -uo pipefail
mkdir -p /workspace
tar -C /source --exclude=.git -cf - . | tar -C /workspace -xf -
cd /workspace
cp /reports/manifest.jsonl shared-resources/tools/code-block-verify/manifest.jsonl
python3 shared-resources/tools/code-block-verify/verify.py --langs kotlin --strict 2>&1 | tee /reports/run.log
status=$?
for artifact in results.jsonl commands.jsonl summary.json report.md; do cp "shared-resources/tools/code-block-verify/$artifact" /reports/; done
exit "$status"