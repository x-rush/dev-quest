import json,hashlib,subprocess,tempfile,sys,time,urllib.request,urllib.error
from pathlib import Path
sys.path.insert(0,'/source/shared-resources/tools/code-block-verify')
import verify
p=Path('/reports')
blocks=[json.loads(x) for x in (p/'manifest.jsonl').read_text().splitlines()]
rows=[]; commands=[]
def run(args,stdin=None):
    r=subprocess.run(args,input=stdin,capture_output=True,text=True,timeout=30)
    commands.append({'command':args,'stdin':stdin,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    if r.returncode: raise AssertionError(r.stderr)
    return r.stdout
for b in blocks:
    r={k:b[k] for k in ('id','lang','module','file','start','end')}
    r.update(source_sha256=hashlib.sha256(b['content'].encode()).hexdigest(),l1={'status':'PASS','detail':''},l2={'status':'NOT_VERIFIED','detail':'static configuration parsing'})
    try:
        if b['lang']=='jsonc':
            json.loads(verify._parse_jsonc(b['content']))
        else:
            with tempfile.TemporaryDirectory() as td:
                src=Path(td)/'main.go';exe=str(Path(td)/'demo');src.write_text(b['content'])
                run(['go','build','-o',exe,str(src)])
                if 'func newMux(' in b['content']:
                    proc=subprocess.Popen([exe],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                    try:
                        for attempt in range(30):
                            try:
                                with urllib.request.urlopen('http://127.0.0.1:8080/health',timeout=1) as response:
                                    assert response.status==200 and response.read().decode()=='ok\n'
                                break
                            except (OSError,urllib.error.URLError):
                                if attempt==29: raise
                                time.sleep(.1)
                        with urllib.request.urlopen('http://127.0.0.1:8080/users/42',timeout=1) as response:
                            data=json.load(response);assert data['name']=='用户42' and data['email']=='user42@example.com'
                        try: urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8080/users/42',method='POST'),timeout=1)
                        except urllib.error.HTTPError as e: assert e.code==405
                        else: raise AssertionError('POST must return 405')
                        commands.append({'probe':'HTTP integration','assertions':['GET /health:200 ok','GET /users/42:200 expected JSON','POST /users/42:405'],'passed':True})
                    finally:
                        proc.terminate();out,err=proc.communicate(timeout=3)
                    detail='isolated HTTP probes: health, path parameter JSON, method rejection'
                elif 'func validateInput(' in b['content']:
                    assert '程序结束' in run([exe],'')
                    assert '输入有效' in run([exe],'hello\nquit\n')
                    assert '输入过长' in run([exe],'字'*101+'\nquit\n')
                    detail='empty stdin exits; normal input; 101 Unicode code points rejected'
                else:
                    run([exe],'')
                    assert '2.00 + 3.00 = 5.00' in run([exe],'1\n2\n3\n5\n')
                    assert '无效选择' in run([exe],'bad\n5\n')
                    assert '数字无效' in run([exe],'1\nbad\n5\n')
                    detail='EOF exits; addition; invalid menu and numeric input'
                r['l2']={'status':'PASS','detail':detail}
        r['classification']='PASS_CHECKED_SCOPE'
    except Exception as exc:
        r['l2']={'status':'FAIL','detail':repr(exc)};r['classification']='NEEDS_REVIEW'
    rows.append(r)
(p/'results.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
(p/'commands.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in commands))
(p/'summary.json').write_text(json.dumps({'scope':'selected Go build/runtime/HTTP probes and JSONC parse; network disabled','results':[(r['file'],r['classification']) for r in rows],'go':run(['go','version'])},ensure_ascii=False,indent=2))
print([(r['file'],r['classification']) for r in rows])
sys.exit(any(r['classification']=='NEEDS_REVIEW' for r in rows))